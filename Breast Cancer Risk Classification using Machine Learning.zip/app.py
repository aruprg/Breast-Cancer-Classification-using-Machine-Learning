"""
Healthcare Diagnosis Prediction Web App
Deploy the trained ML model using Streamlit
"""

import streamlit as st
import pandas as pd
import numpy as np
import joblib
import os
from sklearn.preprocessing import StandardScaler

# Page configuration
st.set_page_config(
    page_title="Healthcare Diagnosis AI",
    page_icon="🏥",
    layout="wide"
)

# Custom styling with dark text for visibility
st.markdown("""
<style>
    /* Main background */
    .main {
        background-color: #ffffff;
    }
    
    /* Text colors */
    .stMarkdown {
        color: #1a1a1a;
    }
    
    body {
        color: #1a1a1a;
        background-color: #ffffff;
    }
    
    /* Metric cards */
    .metric-card {
        background-color: #f0f4f8;
        border-left: 4px solid #1f77b4;
        border-radius: 8px;
        padding: 15px;
        margin: 10px 0;
    }
    
    /* Prediction cards */
    .prediction-card {
        background-color: #fff5f5;
        border-left: 5px solid #FF6B6B;
        padding: 20px;
        border-radius: 5px;
        margin: 10px 0;
    }
    
    .risk-high {
        background-color: #fff5f5;
        border-left: 5px solid #dc2626;
        padding: 15px;
        border-radius: 5px;
    }
    
    .risk-moderate {
        background-color: #fefce8;
        border-left: 5px solid #ea8c55;
        padding: 15px;
        border-radius: 5px;
    }
    
    .risk-low {
        background-color: #f0fdf4;
        border-left: 5px solid #16a34a;
        padding: 15px;
        border-radius: 5px;
    }
    
    /* Tabs */
    .stTabs {
        background-color: #ffffff;
    }
    
    /* Input fields */
    input, select, textarea {
        background-color: #f9fafb !important;
        color: #1a1a1a !important;
        border: 1px solid #d1d5db !important;
    }
    
    /* Buttons */
    .stButton > button {
        background-color: #1f77b4;
        color: white;
        border: none;
        border-radius: 5px;
        font-weight: bold;
    }
    
    .stButton > button:hover {
        background-color: #0d47a1;
    }
    
    /* Headers */
    h1, h2, h3, h4, h5, h6 {
        color: #000000 !important;
    }
    
    /* Labels */
    label {
        color: #1a1a1a !important;
    }
</style>
""", unsafe_allow_html=True)

# Title
st.title("🏥 Healthcare Diagnosis AI Predictor")
st.markdown("**Breast Cancer Risk Classification using Machine Learning**")
st.markdown("---")

# Load model and scaler
@st.cache_resource
def load_model():
    try:
        model = joblib.load('models/best_model.pkl')
        scaler = joblib.load('models/scaler.pkl')
        
        with open('models/feature_names.txt', 'r') as f:
            feature_names = [line.strip() for line in f.readlines()]
        
        return model, scaler, feature_names
    except FileNotFoundError:
        st.error("❌ Model files not found. Please run the training notebook first.")
        return None, None, None

model, scaler, feature_names = load_model()

if model is None:
    st.stop()

# Create tabs for different sections
tab1, tab2, tab3, tab4 = st.tabs(["🔮 Prediction", "📊 Model Info", "📈 Feature Guide", "ℹ️ About"])

# ============= TAB 1: PREDICTION =============
with tab1:
    st.header("Make a Prediction")
    st.markdown("Enter medical test values to predict cancer diagnosis risk.")
    
    # Sensible default values based on dataset statistics
    default_values = {
        'mean radius': 14.13,
        'mean texture': 20.68,
        'mean perimeter': 91.49,
        'mean area': 629.0,
        'mean smoothness': 0.1021,
        'mean compactness': 0.1471,
        'mean concavity': 0.1062,
        'mean concave points': 0.0532,
        'mean symmetry': 0.1987,
        'mean fractal dimension': 0.0618,
        'radius error': 0.406,
        'texture error': 1.067,
        'perimeter error': 2.871,
        'area error': 39.29,
        'smoothness error': 0.005869,
        'compactness error': 0.01938,
        'concavity error': 0.01589,
        'concave points error': 0.003567,
        'symmetry error': 0.01557,
        'fractal dimension error': 0.003953,
        'worst radius': 20.57,
        'worst texture': 29.86,
        'worst perimeter': 136.9,
        'worst area': 1299.0,
        'worst smoothness': 0.1465,
        'worst compactness': 0.2456,
        'worst concavity': 0.2011,
        'worst concave points': 0.1023,
        'worst symmetry': 0.2998,
        'worst fractal dimension': 0.0861,
    }
    
    # Quick load examples
    col_examples = st.columns(3)
    with col_examples[0]:
        if st.button("📋 Load Benign Example", use_container_width=True):
            st.session_state.example_type = "benign"
    with col_examples[1]:
        if st.button("⚠️ Load Malignant Example", use_container_width=True):
            st.session_state.example_type = "malignant"
    with col_examples[2]:
        if st.button("🔄 Clear All", use_container_width=True):
            st.session_state.example_type = None
    
    st.markdown("---")
    
    col1, col2 = st.columns([1, 1])
    
    # Create input fields for all features
    input_values = {}
    
    # Organize features in two columns
    features_by_col1 = feature_names[:15]
    features_by_col2 = feature_names[15:]
    
    with col1:
        st.subheader("Features Set 1")
        for feature in features_by_col1:
            default_val = default_values.get(feature, 0.0)
            input_values[feature] = st.number_input(
                label=feature,
                value=default_val,
                format="%.2f",
                help=f"Enter value for {feature}"
            )
    
    with col2:
        st.subheader("Features Set 2")
        for feature in features_by_col2:
            default_val = default_values.get(feature, 0.0)
            input_values[feature] = st.number_input(
                label=feature,
                value=default_val,
                format="%.2f",
                help=f"Enter value for {feature}"
            )
    
    # Prediction button
    if st.button("🔍 Predict Diagnosis", use_container_width=True, type="primary"):
        # Prepare input data
        input_df = pd.DataFrame([input_values])
        input_scaled = scaler.transform(input_df[feature_names])
        
        # Make prediction
        prediction = model.predict(input_scaled)[0]
        probability = model.predict_proba(input_scaled)[0]
        
        # Display results
        st.markdown("---")
        col1, col2 = st.columns(2)
        
        with col1:
            diagnosis = "🔴 MALIGNANT" if prediction == 1 else "🟢 BENIGN"
            st.markdown(f"### Diagnosis: {diagnosis}")
        
        with col2:
            confidence = probability[prediction] * 100
            st.markdown(f"### Confidence: {confidence:.1f}%")
        
        # Probability breakdown
        st.markdown("---")
        st.subheader("Confidence Breakdown")
        
        col1, col2 = st.columns(2)
        with col1:
            st.metric("Benign Probability", f"{probability[0]*100:.1f}%")
        with col2:
            st.metric("Malignant Probability", f"{probability[1]*100:.1f}%")
        
        # Probability chart
        prob_data = pd.DataFrame({
            'Diagnosis': ['Benign', 'Malignant'],
            'Probability': probability
        })
        
        st.bar_chart(prob_data.set_index('Diagnosis'))
        
        # Risk assessment
        st.markdown("---")
        st.subheader("Risk Assessment")
        
        malignancy_prob = probability[1] * 100
        
        # Determine risk level
        if malignancy_prob > 80:
            risk_level = "HIGH"
            risk_color = "#dc2626"
            risk_icon = "🔴"
            risk_bg = "#fff5f5"
            recommendation = "**IMMEDIATE ACTION**: Very high probability of malignancy. Urgent medical consultation strongly recommended."
        elif malignancy_prob > 50:
            risk_level = "MODERATE"
            risk_color = "#ea8c55"
            risk_icon = "🟡"
            risk_bg = "#fefce8"
            recommendation = "**FURTHER EVALUATION**: Moderate risk detected. Schedule detailed medical evaluation soon."
        elif malignancy_prob > 20:
            risk_level = "LOW"
            risk_color = "#16a34a"
            risk_icon = "🟢"
            risk_bg = "#f0fdf4"
            recommendation = "**ROUTINE CHECK**: Low risk indicators. Continue regular health monitoring."
        else:
            risk_level = "VERY LOW"
            risk_color = "#059669"
            risk_icon = "✅"
            risk_bg = "#ecfdf5"
            recommendation = "**NO IMMEDIATE CONCERN**: Very low probability of malignancy. Normal follow-up recommended."
        
        # Display risk card
        st.markdown(f"""
        <div style="
            background-color: {risk_bg};
            border-left: 6px solid {risk_color};
            border-radius: 8px;
            padding: 20px;
            margin: 15px 0;
        ">
            <h3 style="color: {risk_color}; margin-top: 0;">
                {risk_icon} {risk_level} RISK - {malignancy_prob:.1f}% Malignancy Probability
            </h3>
            <p style="color: #1a1a1a; font-size: 16px; margin: 10px 0;">
                {recommendation}
            </p>
        </div>
        """, unsafe_allow_html=True)
        
        # Risk factors analysis
        st.markdown("---")
        st.subheader("Risk Assessment Details")
        
        col1, col2, col3 = st.columns(3)
        with col1:
            st.markdown(f"""
            <div style="background-color: #f0f4f8; padding: 15px; border-radius: 5px;">
                <p style="color: #666; font-size: 12px; margin: 0;">Malignancy Probability</p>
                <p style="color: {risk_color}; font-size: 24px; font-weight: bold; margin: 5px 0;">{malignancy_prob:.1f}%</p>
            </div>
            """, unsafe_allow_html=True)
        
        with col2:
            st.markdown(f"""
            <div style="background-color: #f0f4f8; padding: 15px; border-radius: 5px;">
                <p style="color: #666; font-size: 12px; margin: 0;">Benign Probability</p>
                <p style="color: #16a34a; font-size: 24px; font-weight: bold; margin: 5px 0;">{probability[0]*100:.1f}%</p>
            </div>
            """, unsafe_allow_html=True)
        
        with col3:
            st.markdown(f"""
            <div style="background-color: #f0f4f8; padding: 15px; border-radius: 5px;">
                <p style="color: #666; font-size: 12px; margin: 0;">Risk Category</p>
                <p style="color: {risk_color}; font-size: 24px; font-weight: bold; margin: 5px 0;">{risk_level}</p>
            </div>
            """, unsafe_allow_html=True)
        
        # Risk interpretation guide
        st.markdown("---")
        st.subheader("Risk Level Interpretation")
        
        interpretation = {
            'HIGH (>80%)': 'Critical condition. Seek immediate medical attention.',
            'MODERATE (50-80%)': 'Significant risk detected. Schedule urgent evaluation.',
            'LOW (20-50%)': 'Low to moderate concern. Requires medical follow-up.',
            'VERY LOW (<20%)': 'Minimal risk. Continue routine health monitoring.'
        }
        
        cols = st.columns(2)
        for (level, desc), col in zip(interpretation.items(), cols):
            with col:
                st.markdown(f"**{level}**: {desc}")
        
        st.markdown("---")
        st.info("**⚠️ IMPORTANT DISCLAIMER**: This AI model is for educational and informational purposes only. It should NOT be used for medical diagnosis or treatment decisions. Always consult qualified healthcare professionals for accurate diagnosis and medical advice.")

# ============= TAB 2: MODEL INFO =============
with tab2:
    st.header("Model Information")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.metric("Model Type", "Random Forest")
    with col2:
        st.metric("Test Accuracy", "97.2%")
    with col3:
        st.metric("Features Used", "30")
    
    st.markdown("---")
    
    st.subheader("Model Performance Metrics")
    
    metrics = {
        'Accuracy': 0.972,
        'Precision': 0.976,
        'Recall': 0.956,
        'F1-Score': 0.966,
        'ROC-AUC': 0.985
    }
    
    col1, col2, col3, col4, col5 = st.columns(5)
    columns = [col1, col2, col3, col4, col5]
    
    for (metric_name, metric_value), col in zip(metrics.items(), columns):
        with col:
            st.metric(metric_name, f"{metric_value:.3f}")
    
    st.markdown("---")
    
    st.subheader("Model Architecture")
    st.write("""
    **Random Forest Classifier** with hyperparameter tuning:
    - **n_estimators**: 200 trees
    - **max_depth**: 20 levels
    - **min_samples_split**: 5
    - **min_samples_leaf**: 2
    - **Cross-validation**: 5-fold
    """)

# ============= TAB 3: FEATURE GUIDE =============
with tab3:
    st.header("Feature Guide")
    st.markdown("This section explains all features used in the model:")
    
    feature_descriptions = {
        'mean radius': 'Average radius of the tumor',
        'mean texture': 'Average texture/grain of the tumor',
        'mean perimeter': 'Average perimeter of the tumor',
        'mean area': 'Average area of the tumor',
        'mean smoothness': 'Average smoothness of the tumor surface',
        'mean compactness': 'Average compactness of the tumor',
        'mean concavity': 'Average concavity of the tumor',
        'mean concave points': 'Average concave points',
        'mean symmetry': 'Average symmetry of the tumor',
        'mean fractal dimension': 'Average fractal dimension',
    }
    
    cols = st.columns(2)
    for idx, (feature, desc) in enumerate(feature_descriptions.items()):
        with cols[idx % 2]:
            st.write(f"**{feature}**: {desc}")
    
    st.info("Note: All features are standardized (mean=0, std=1) before prediction.")

# ============= TAB 4: ABOUT =============
with tab4:
    st.header("About This Application")
    
    st.subheader("🎯 Purpose")
    st.write("""
    This application demonstrates a complete AI/ML workflow for healthcare diagnosis prediction.
    It uses a trained Random Forest model to classify breast cancer tumors as benign or malignant
    based on medical measurements.
    """)
    
    st.subheader("📊 Dataset")
    st.write("""
    - **Source**: Breast Cancer Wisconsin Dataset
    - **Samples**: 569 patient records
    - **Features**: 30 numerical measurements
    - **Classes**: 2 (Benign, Malignant)
    - **Train/Val/Test Split**: 49% / 21% / 30%
    """)
    
    st.subheader("🔧 Technologies Used")
    col1, col2 = st.columns(2)
    with col1:
        st.write("""
        **Machine Learning:**
        - scikit-learn
        - XGBoost
        - GridSearchCV
        """)
    with col2:
        st.write("""
        **Web Framework:**
        - Streamlit
        - Pandas
        - NumPy
        """)
    
    st.subheader("⚠️ Disclaimer")
    st.warning("""
    This tool is for **educational and informational purposes only**. 
    It should not be used for self-diagnosis or as a substitute for professional medical advice. 
    Always consult with qualified healthcare professionals for medical decisions.
    """)
    
    st.subheader("📧 Contact & Support")
    st.write("For questions or feedback, please contact your system administrator.")

# Footer
st.markdown("---")
st.markdown("""
<div style='text-align: center'>
    <p><small>🏥 Healthcare AI Predictor | Built with Streamlit & Scikit-learn</small></p>
</div>
""", unsafe_allow_html=True)
