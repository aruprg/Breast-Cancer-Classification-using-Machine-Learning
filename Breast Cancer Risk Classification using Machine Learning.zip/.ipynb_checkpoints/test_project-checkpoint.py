#!/usr/bin/env python3
"""
Quick Test Script for AI/ML Project
Tests all components to ensure everything is working
"""

import sys

def test_imports():
    """Test all required imports"""
    try:
        print("[TEST 1] Testing imports...")
        import pandas as pd
        import numpy as np
        from sklearn.datasets import load_breast_cancer
        from sklearn.model_selection import train_test_split
        from sklearn.preprocessing import StandardScaler
        from sklearn.ensemble import RandomForestClassifier
        from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
        print("  PASSED: All imports successful")
        return True
    except ImportError as e:
        print(f"  FAILED: Import error - {e}")
        return False

def test_data_loading():
    """Test data loading and preparation"""
    try:
        print("[TEST 2] Testing data loading and preparation...")
        import pandas as pd
        from sklearn.datasets import load_breast_cancer
        
        data = load_breast_cancer()
        X = pd.DataFrame(data.data, columns=data.feature_names)
        y = pd.Series(data.target, name='diagnosis')
        
        assert X.shape == (569, 30), "Dataset shape mismatch"
        assert len(y) == 569, "Target length mismatch"
        print(f"  PASSED: Dataset loaded ({X.shape[0]} samples, {X.shape[1]} features)")
        return True
    except Exception as e:
        print(f"  FAILED: Data loading error - {e}")
        return False

def test_data_preprocessing():
    """Test data preprocessing"""
    try:
        print("[TEST 3] Testing data preprocessing...")
        import pandas as pd
        import numpy as np
        from sklearn.datasets import load_breast_cancer
        from sklearn.model_selection import train_test_split
        from sklearn.preprocessing import StandardScaler
        
        data = load_breast_cancer()
        X = pd.DataFrame(data.data, columns=data.feature_names)
        y = pd.Series(data.target)
        
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.3, random_state=42
        )
        
        scaler = StandardScaler()
        X_train_scaled = scaler.fit_transform(X_train)
        X_test_scaled = scaler.transform(X_test)
        
        assert X_train_scaled.shape[0] == len(X_train), "Train set size mismatch"
        assert X_test_scaled.shape[0] == len(X_test), "Test set size mismatch"
        print(f"  PASSED: Data split ({len(X_train)} train, {len(X_test)} test)")
        return True
    except Exception as e:
        print(f"  FAILED: Preprocessing error - {e}")
        return False

def test_model_training():
    """Test model training"""
    try:
        print("[TEST 4] Testing model training...")
        import pandas as pd
        from sklearn.datasets import load_breast_cancer
        from sklearn.model_selection import train_test_split
        from sklearn.preprocessing import StandardScaler
        from sklearn.ensemble import RandomForestClassifier
        
        data = load_breast_cancer()
        X = pd.DataFrame(data.data, columns=data.feature_names)
        y = pd.Series(data.target)
        
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.3, random_state=42
        )
        
        scaler = StandardScaler()
        X_train_scaled = scaler.fit_transform(X_train)
        X_test_scaled = scaler.transform(X_test)
        
        model = RandomForestClassifier(n_estimators=100, random_state=42, n_jobs=-1)
        model.fit(X_train_scaled, y_train)
        
        print("  PASSED: Model trained successfully")
        return True
    except Exception as e:
        print(f"  FAILED: Model training error - {e}")
        return False

def test_model_evaluation():
    """Test model evaluation"""
    try:
        print("[TEST 5] Testing model evaluation...")
        import pandas as pd
        from sklearn.datasets import load_breast_cancer
        from sklearn.model_selection import train_test_split
        from sklearn.preprocessing import StandardScaler
        from sklearn.ensemble import RandomForestClassifier
        from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
        
        data = load_breast_cancer()
        X = pd.DataFrame(data.data, columns=data.feature_names)
        y = pd.Series(data.target)
        
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.3, random_state=42
        )
        
        scaler = StandardScaler()
        X_train_scaled = scaler.fit_transform(X_train)
        X_test_scaled = scaler.transform(X_test)
        
        model = RandomForestClassifier(n_estimators=100, random_state=42, n_jobs=-1)
        model.fit(X_train_scaled, y_train)
        
        y_pred = model.predict(X_test_scaled)
        
        accuracy = accuracy_score(y_test, y_pred)
        precision = precision_score(y_test, y_pred)
        recall = recall_score(y_test, y_pred)
        f1 = f1_score(y_test, y_pred)
        
        assert accuracy > 0.9, f"Accuracy {accuracy:.4f} is too low"
        print(f"  PASSED: Model evaluated")
        print(f"    Accuracy:  {accuracy:.4f}")
        print(f"    Precision: {precision:.4f}")
        print(f"    Recall:    {recall:.4f}")
        print(f"    F1-Score:  {f1:.4f}")
        return True
    except Exception as e:
        print(f"  FAILED: Evaluation error - {e}")
        return False

def main():
    """Run all tests"""
    print("\n" + "="*60)
    print("TESTING AI/ML PROJECT")
    print("="*60 + "\n")
    
    tests = [
        test_imports,
        test_data_loading,
        test_data_preprocessing,
        test_model_training,
        test_model_evaluation
    ]
    
    results = []
    for test in tests:
        try:
            result = test()
            results.append(result)
        except Exception as e:
            print(f"  ERROR: {e}")
            results.append(False)
        print()
    
    # Summary
    print("="*60)
    passed = sum(results)
    total = len(results)
    print(f"RESULTS: {passed}/{total} tests passed")
    print("="*60)
    
    if all(results):
        print("\nSUCCESS! All tests passed.")
        print("Your AI/ML project is ready to use!")
        print("\nNext steps:")
        print("1. Run: jupyter notebook AI_ML_Complete_Guide.ipynb")
        print("2. Click 'Restart and Run All' to train the model")
        print("3. Run: streamlit run app.py for the web app")
        return 0
    else:
        print(f"\nFAILURE: {total - passed} test(s) failed")
        return 1

if __name__ == "__main__":
    sys.exit(main())
