# Quick Reference Guide - AI/ML Project Development

## 🎯 8-Stage ML Development Framework

### Stage 1: Understand the Basics
```python
# Key Concepts
- Supervised Learning: labeled data (features → targets)
  - Classification: predicting categories
  - Regression: predicting continuous values
  
- Unsupervised Learning: unlabeled data
  - Clustering: grouping similar items
  - Dimensionality Reduction: reducing features
  
- Reinforcement Learning: sequential decisions
  - Agent learns through interaction

# Essential Libraries
import pandas as pd        # Data manipulation
import numpy as np         # Numerical computing
from sklearn import *      # ML algorithms
import matplotlib.pyplot   # Visualization
```

---

### Stage 2: Select Problem Domain
```python
# Define Problem Statement
Problem = {
    'Domain': 'Healthcare',
    'Task': 'Binary Classification',
    'Input': '30 medical measurements',
    'Output': 'Benign or Malignant',
    'Impact': 'Early diagnosis improves treatment'
}

# Choose Algorithm Type
if need_categories:
    algorithm_type = 'Classification'
elif need_groups:
    algorithm_type = 'Clustering'
elif need_numbers:
    algorithm_type = 'Regression'
elif need_decisions:
    algorithm_type = 'Reinforcement Learning'
```

---

### Stage 3: Collect & Prepare Data
```python
# Load Data
import pandas as pd
data = pd.read_csv('dataset.csv')
X = data.drop('target', axis=1)
y = data['target']

# Explore Data
print(data.shape)              # Dimensions
print(data.isnull().sum())     # Missing values
print(data.describe())         # Statistics
data.hist(figsize=(10,10))     # Visualize

# Clean Data
data = data.dropna()           # Remove null values
data = data.drop_duplicates()  # Remove duplicates

# Preprocess
from sklearn.preprocessing import StandardScaler
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)
```

---

### Stage 4: Choose AI Approach
```python
# Classification Algorithms
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.svm import SVC

# Regression Algorithms
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor

# Clustering Algorithms
from sklearn.cluster import KMeans, DBSCAN

# Deep Learning
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Conv2D

# Choose based on:
# - Data size and complexity
# - Interpretability needs
# - Computational resources
# - Training time constraints
```

---

### Stage 5: Model Building & Training
```python
from sklearn.model_selection import train_test_split

# Split Data
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

# Further split for validation
X_train, X_val, y_train, y_val = train_test_split(
    X_train, y_train, test_size=0.25, random_state=42
)
# Result: 60% train, 20% val, 20% test

# Train Model
model = RandomForestClassifier(n_estimators=100, random_state=42)
model.fit(X_train, y_train)

# Make Predictions
y_pred = model.predict(X_test)
y_pred_proba = model.predict_proba(X_test)
```

---

### Stage 6: Evaluate Performance
```python
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    confusion_matrix, classification_report, roc_auc_score, roc_curve
)

# Classification Metrics
accuracy = accuracy_score(y_true, y_pred)
precision = precision_score(y_true, y_pred)
recall = recall_score(y_true, y_pred)
f1 = f1_score(y_true, y_pred)
roc_auc = roc_auc_score(y_true, y_pred_proba)

# Confusion Matrix
cm = confusion_matrix(y_true, y_pred)
# [[TN, FP],
#  [FN, TP]]

# Classification Report
print(classification_report(y_true, y_pred))

# Regression Metrics
from sklearn.metrics import mean_squared_error, r2_score
mse = mean_squared_error(y_true, y_pred)
rmse = np.sqrt(mse)
r2 = r2_score(y_true, y_pred)
```

---

### Stage 7: Fine-tune Hyperparameters
```python
from sklearn.model_selection import GridSearchCV, RandomizedSearchCV

# Define Parameter Grid
param_grid = {
    'n_estimators': [50, 100, 200],
    'max_depth': [10, 15, 20],
    'min_samples_split': [2, 5, 10]
}

# Grid Search (exhaustive)
grid_search = GridSearchCV(
    RandomForestClassifier(),
    param_grid,
    cv=5,
    scoring='f1',
    n_jobs=-1
)
grid_search.fit(X_train, y_train)

print(f"Best params: {grid_search.best_params_}")
print(f"Best score: {grid_search.best_score_}")

best_model = grid_search.best_estimator_

# Random Search (faster for large grids)
from sklearn.model_selection import RandomizedSearchCV
random_search = RandomizedSearchCV(
    RandomForestClassifier(),
    param_grid,
    n_iter=20,
    cv=5,
    random_state=42
)
```

---

### Stage 8: Test & Deploy
```python
# Final Evaluation on Test Set
y_test_pred = best_model.predict(X_test)
test_accuracy = accuracy_score(y_test, y_test_pred)

# Check for Overfitting
train_score = best_model.score(X_train, y_train)
test_score = best_model.score(X_test, y_test)
print(f"Train: {train_score:.4f}, Test: {test_score:.4f}")

# Save Model
import joblib
joblib.dump(best_model, 'model.pkl')
joblib.dump(scaler, 'scaler.pkl')

# Load Model
model = joblib.load('model.pkl')
scaler = joblib.load('scaler.pkl')

# Deploy with Streamlit
# app.py
import streamlit as st
import joblib

model = joblib.load('model.pkl')
st.title('ML Prediction App')

# Get user input
feature1 = st.slider('Feature 1', 0, 100)
feature2 = st.slider('Feature 2', 0, 100)

# Make prediction
if st.button('Predict'):
    prediction = model.predict([[feature1, feature2]])
    st.write(f'Prediction: {prediction[0]}')
```

---

## 📊 Common Algorithms Cheat Sheet

### Classification
| Algorithm | Best For | Pros | Cons |
|-----------|----------|------|------|
| Decision Tree | Small-medium datasets | Interpretable, fast | Overfitting |
| Random Forest | General purpose | Robust, feature importance | Less interpretable |
| SVM | High-dimensional | Good generalization | Slow on large data |
| Logistic Regression | Linear problems | Simple, fast | Limited complexity |
| Gradient Boosting | High accuracy | Best performance | Slow training |
| Neural Network | Complex patterns | Very flexible | Requires more data |

### Regression
| Algorithm | Best For | Pros | Cons |
|-----------|----------|------|------|
| Linear Regression | Linear relationships | Simple, interpretable | Limited complexity |
| Random Forest | General purpose | Robust, non-linear | Less interpretable |
| SVR | High dimensions | Good generalization | Slow on large data |
| Polynomial Regression | Curved relationships | Flexible | Overfitting risk |
| Neural Network | Complex patterns | Very flexible | Requires more data |

### Clustering
| Algorithm | Best For | Pros | Cons |
|-----------|----------|------|------|
| K-Means | General grouping | Fast, simple | Requires k parameter |
| DBSCAN | Dense clusters | Finds any shape | Sensitive to parameters |
| Hierarchical | Tree structure | Interpretable | Slow on large data |
| Gaussian Mixture | Probabilistic | Flexible | Complex computation |

---

## 🔍 Debugging Checklist

### Low Accuracy?
- [ ] Check data quality (missing values, outliers)
- [ ] Verify feature scaling/normalization
- [ ] Check train/val/test split
- [ ] Try different algorithms
- [ ] Collect more data
- [ ] Engineer better features

### Overfitting (High train, Low test)?
- [ ] Use regularization (L1, L2)
- [ ] Reduce model complexity
- [ ] Collect more training data
- [ ] Use dropout (for neural networks)
- [ ] Early stopping

### Underfitting (Low train, Low test)?
- [ ] Use more complex model
- [ ] Engineer better features
- [ ] Train longer
- [ ] Reduce regularization
- [ ] Collect more diverse data

### Slow Training?
- [ ] Reduce data size (sampling)
- [ ] Use simpler model
- [ ] Reduce feature count (PCA)
- [ ] Use GPU acceleration
- [ ] Use approximation algorithms

---

## 📈 Model Selection Flowchart

```
Start
  ↓
Supervised or Unsupervised?
  ├→ Supervised
  │   ├→ Regression or Classification?
  │   │   ├→ Regression
  │   │   │   └→ Linear/Tree/NN
  │   │   └→ Classification
  │   │       ├→ Binary/Multiclass?
  │   │       │   ├→ Binary
  │   │       │   │   └→ Logistic/Tree/SVM
  │   │       │   └→ Multiclass
  │   │       │       └→ RF/GB/NN
  └→ Unsupervised
      ├→ Clustering
      │   └→ K-Means/DBSCAN/Hierarchical
      └→ Dimensionality Reduction
          └→ PCA/t-SNE
```

---

## 🎓 Quick Tips

1. **Always split data** before training (train/val/test)
2. **Scale features** for distance-based algorithms
3. **Use cross-validation** for better evaluation
4. **Start simple**, then increase complexity
5. **Monitor both training and test metrics**
6. **Save best model** during training
7. **Document everything** for reproducibility
8. **Test on new data** before production
9. **Version your code** with Git
10. **Keep a model log** of experiments

---

## 🚀 Useful Websites & Tools

- [Scikit-learn](https://scikit-learn.org/) - Classical ML
- [TensorFlow/Keras](https://tensorflow.org/) - Deep Learning
- [PyTorch](https://pytorch.org/) - Deep Learning
- [XGBoost](https://xgboost.readthedocs.io/) - Gradient Boosting
- [Kaggle](https://kaggle.com/) - Datasets & Competitions
- [UCI ML Repository](https://archive.ics.uci.edu/ml/) - Classic Datasets
- [Streamlit](https://streamlit.io/) - Web Apps
- [Jupyter](https://jupyter.org/) - Notebooks

---

Happy Learning! 🎉
