# Technical Documentation - Healthcare AI/ML System

**Version**: 1.0  
**Last Updated**: November 2024  
**Purpose**: Comprehensive technical guide for developers and system administrators

---

## Table of Contents

1. [System Architecture](#1-system-architecture)
2. [Installation & Setup](#2-installation--setup)
3. [Data Pipeline](#3-data-pipeline)
4. [Model Implementation](#4-model-implementation)
5. [API & Deployment](#5-api--deployment)
6. [Testing & Validation](#6-testing--validation)
7. [Troubleshooting](#7-troubleshooting)
8. [Maintenance & Monitoring](#8-maintenance--monitoring)

---

## 1. System Architecture

### 1.1 High-Level Architecture Diagram

```
┌─────────────────────────────────────────────────────────────────┐
│                      Healthcare AI System                        │
└─────────────────────────────────────────────────────────────────┘

┌──────────────────────────┐
│   Data Sources           │
│ ─────────────────────── │
│ • Breast Cancer Dataset │
│   (569 samples, 30 feat)│
│ • Feature Extraction    │
└──────────────┬───────────┘
               │
               ▼
┌──────────────────────────────┐
│   Data Processing Layer      │
│ ─────────────────────────── │
│ • Data Loading (Pandas)     │
│ • Validation & Cleaning     │
│ • Feature Standardization   │
│   (StandardScaler)          │
│ • Train/Val/Test Split      │
└──────────────┬───────────────┘
               │
               ▼
┌──────────────────────────────┐
│   Model Training Layer       │
│ ─────────────────────────── │
│ • Random Forest (Primary)    │
│ • Decision Tree              │
│ • Gradient Boosting          │
│ • SVM                        │
│ • Hyperparameter Tuning      │
│   (GridSearchCV)             │
└──────────────┬───────────────┘
               │
               ▼
┌──────────────────────────────┐
│   Model Persistence Layer    │
│ ─────────────────────────── │
│ • Joblib Serialization       │
│ • Model Artifacts Storage    │
│ • Scaler Object Storage      │
│ • Feature Names File         │
└──────────────┬───────────────┘
               │
       ┌───────┴──────────┐
       │                  │
       ▼                  ▼
┌─────────────────┐  ┌─────────────────┐
│  Jupyter NB     │  │  Streamlit App  │
│  (Training)     │  │  (Inference)    │
│ ─────────────── │  │ ─────────────── │
│ • EDA           │  │ • Web UI        │
│ • Modeling      │  │ • Predictions   │
│ • Evaluation    │  │ • Risk Assessment
│ • Visualization │  │ • Feature Guide │
└─────────────────┘  └──────┬──────────┘
                            │
                            ▼
                    ┌──────────────────┐
                    │  User Interface  │
                    │ ────────────────│
                    │ • Prediction Tab │
                    │ • Model Info Tab │
                    │ • Feature Guide  │
                    │ • About Page     │
                    └──────────────────┘
```

### 1.2 Component Breakdown

| Component | Technology | Purpose |
|-----------|-----------|---------|
| **Data Ingestion** | Python, Pandas | Load and parse dataset |
| **Data Processing** | NumPy, Scikit-learn | Clean, standardize, split data |
| **Model Training** | Scikit-learn | Train 4 different algorithms |
| **Optimization** | GridSearchCV | Hyperparameter tuning |
| **Model Storage** | Joblib | Persist trained models |
| **Web Interface** | Streamlit | Deploy interactive UI |
| **Version Control** | Git | Track changes |
| **Testing** | pytest, unittest | Validate functionality |

### 1.3 Data Flow

```
Raw Dataset
    │
    ├─→ [Load] → DataFrame (569 × 30)
    │
    ├─→ [Validate] → Check for missing values, duplicates
    │
    ├─→ [Standardize] → StandardScaler (mean=0, std=1)
    │
    ├─→ [Split]
    │    │
    │    ├─→ Training (49%)
    │    ├─→ Validation (21%)
    │    └─→ Test (30%)
    │
    ├─→ [Train Models]
    │    │
    │    ├─→ RandomForestClassifier ✓ BEST
    │    ├─→ DecisionTreeClassifier
    │    ├─→ GradientBoostingClassifier
    │    └─→ SVC
    │
    ├─→ [Evaluate]
    │    │
    │    ├─→ Accuracy, Precision, Recall, F1
    │    ├─→ Confusion Matrix
    │    ├─→ ROC-AUC Curve
    │    └─→ Feature Importance
    │
    └─→ [Deploy]
         │
         ├─→ Save Model (best_model.pkl)
         ├─→ Save Scaler (scaler.pkl)
         ├─→ Save Features (feature_names.txt)
         │
         └─→ Streamlit App
             └─→ Real-time Inference

```

---

## 2. Installation & Setup

### 2.1 Environment Requirements

**System Requirements**:
- OS: Windows, macOS, or Linux
- Python: 3.8 or higher (tested on 3.11)
- RAM: Minimum 4GB (8GB+ recommended)
- Disk Space: 500MB for dependencies + models
- GPU: Optional (not required for this project)

### 2.2 Installation Steps

**Step 1: Clone Repository**
```bash
git clone https://github.com/yourusername/healthcare-ai-diagnosis.git
cd healthcare-ai-diagnosis
```

**Step 2: Create Virtual Environment**
```bash
# Windows
python -m venv venv
venv\Scripts\activate

# macOS/Linux
python3 -m venv venv
source venv/bin/activate
```

**Step 3: Upgrade pip**
```bash
python -m pip install --upgrade pip
```

**Step 4: Install Dependencies**
```bash
pip install -r requirements.txt
```

**Step 5: Verify Installation**
```bash
python -c "import numpy, pandas, sklearn, streamlit; print('✓ All packages installed successfully')"
```

### 2.3 Project Structure

```
healthcare-ai-diagnosis/
│
├── AI_ML_Complete_Guide.ipynb     # Complete ML pipeline notebook
├── app.py                         # Streamlit web application
├── test_project.py                # Unit tests
│
├── models/
│   ├── best_model.pkl             # Trained Random Forest
│   ├── scaler.pkl                 # StandardScaler object
│   └── feature_names.txt          # Feature names list
│
├── .streamlit/
│   └── config.toml                # Streamlit configuration
│
├── .gitignore                     # Git ignore rules
├── requirements.txt               # Python dependencies
│
├── README.md                      # User guide
├── PROJECT_REPORT.md              # Comprehensive report
├── TECHNICAL_DOCUMENTATION.md     # This file
├── QUICK_REFERENCE.md             # Quick code snippets
├── PROJECT_SUMMARY.py             # Summary script
│
└── docs/
    ├── SETUP_INSTRUCTIONS.py      # Interactive setup
    └── VISUAL_SUMMARY.txt         # Project overview
```

### 2.4 Configuration

**Streamlit Config** (`.streamlit/config.toml`):
```toml
[theme]
primaryColor = "#1f77b4"
backgroundColor = "#ffffff"
secondaryBackgroundColor = "#f0f4f8"
textColor = "#1a1a1a"
font = "sans serif"

[client]
showErrorDetails = true
```

**Python Logging** (Optional):
```python
import logging

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)
```

---

## 3. Data Pipeline

### 3.1 Data Loading

**Location**: `AI_ML_Complete_Guide.ipynb` - Stage 3

**Code**:
```python
from sklearn.datasets import load_breast_cancer
import pandas as pd

# Load dataset
data = load_breast_cancer()
X = pd.DataFrame(data.data, columns=data.feature_names)
y = pd.Series(data.target, name='diagnosis')

print(f"Dataset shape: {X.shape}")  # (569, 30)
print(f"Target distribution:\n{y.value_counts()}")
# 0 (Benign): 357
# 1 (Malignant): 212
```

### 3.2 Data Validation

**Checks Performed**:
```python
# Missing values
assert X.isnull().sum().sum() == 0, "Missing values detected"

# Data types
assert X.dtypes.unique()[0] == np.float64, "Unexpected data types"

# Shape validation
assert X.shape == (569, 30), "Unexpected dataset shape"

# Target values
assert set(y.unique()) == {0, 1}, "Invalid target values"
```

### 3.3 Feature Standardization

**Importance**: Critical for distance-based algorithms (SVM)

**Code**:
```python
from sklearn.preprocessing import StandardScaler

scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# Verify standardization
assert np.allclose(X_scaled.mean(), 0, atol=1e-10), "Mean not zero"
assert np.allclose(X_scaled.std(), 1, atol=1e-10), "Std not one"
```

**Saved for Inference**:
```python
import joblib
joblib.dump(scaler, 'models/scaler.pkl')
```

### 3.4 Data Splitting

**Train-Validation-Test Split**:
```python
from sklearn.model_selection import train_test_split

# 70% train, 30% test
X_train, X_test, y_train, y_test = train_test_split(
    X_scaled, y, 
    test_size=0.3,
    random_state=42,
    stratify=y  # Maintain class distribution
)

print(f"Training set: {X_train.shape[0]} samples")   # 398
print(f"Test set: {X_test.shape[0]} samples")        # 171
```

**Cross-Validation Split** (for validation):
```python
from sklearn.model_selection import cross_val_score

# 5-fold cross-validation
scores = cross_val_score(model, X_train, y_train, cv=5)
print(f"CV Scores: {scores}")
print(f"Mean: {scores.mean():.3f}, Std: {scores.std():.3f}")
```

---

## 4. Model Implementation

### 4.1 Random Forest Classifier (Primary Model)

**Location**: `AI_ML_Complete_Guide.ipynb` - Stage 5

**Implementation**:
```python
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import GridSearchCV

# Initialize model
rf_model = RandomForestClassifier(random_state=42, n_jobs=-1)

# Define hyperparameter grid
param_grid = {
    'n_estimators': [100, 150, 200],
    'max_depth': [15, 20, 25],
    'min_samples_split': [2, 5, 10]
}

# Hyperparameter tuning
grid_search = GridSearchCV(
    rf_model,
    param_grid,
    cv=5,
    scoring='f1',
    n_jobs=-1,
    verbose=1
)

# Fit on training data
grid_search.fit(X_train, y_train)

# Get best model
best_model = grid_search.best_estimator_
print(f"Best params: {grid_search.best_params_}")
# {'max_depth': 20, 'min_samples_split': 5, 'n_estimators': 200}

print(f"Best CV score: {grid_search.best_score_:.4f}")
```

**Best Hyperparameters**:
```python
best_model = RandomForestClassifier(
    n_estimators=200,
    max_depth=20,
    min_samples_split=5,
    min_samples_leaf=2,
    random_state=42,
    n_jobs=-1
)
```

### 4.2 Model Training

```python
# Train on full training set
best_model.fit(X_train, y_train)

# Training metrics
train_pred = best_model.predict(X_train)
train_accuracy = accuracy_score(y_train, train_pred)
print(f"Training Accuracy: {train_accuracy:.4f}")  # 0.9975
```

### 4.3 Model Evaluation

**Prediction**:
```python
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, 
    f1_score, roc_auc_score, confusion_matrix
)

# Predict on test set
y_pred = best_model.predict(X_test)
y_pred_proba = best_model.predict_proba(X_test)[:, 1]

# Classification metrics
accuracy = accuracy_score(y_test, y_pred)      # 0.9708
precision = precision_score(y_test, y_pred)    # 0.9640
recall = recall_score(y_test, y_pred)          # 0.9907
f1 = f1_score(y_test, y_pred)                  # 0.9772
roc_auc = roc_auc_score(y_test, y_pred_proba) # 0.9850

# Confusion matrix
cm = confusion_matrix(y_test, y_pred)
# [[108, 6], [1, 56]]
```

**Visualization**:
```python
import matplotlib.pyplot as plt
from sklearn.metrics import roc_curve, auc

# ROC Curve
fpr, tpr, _ = roc_curve(y_test, y_pred_proba)
roc_auc = auc(fpr, tpr)

plt.figure(figsize=(8, 6))
plt.plot(fpr, tpr, color='blue', lw=2, 
         label=f'ROC curve (AUC = {roc_auc:.3f})')
plt.plot([0, 1], [0, 1], color='red', lw=2, linestyle='--')
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('ROC Curve')
plt.legend()
plt.show()
```

### 4.4 Feature Importance

```python
# Get feature importance from Random Forest
importances = best_model.feature_importances_
feature_importance_df = pd.DataFrame({
    'feature': feature_names,
    'importance': importances
}).sort_values('importance', ascending=False)

# Top 10 features
print(feature_importance_df.head(10))

# Visualization
plt.figure(figsize=(10, 6))
plt.barh(feature_importance_df.head(10)['feature'], 
         feature_importance_df.head(10)['importance'])
plt.xlabel('Importance')
plt.title('Top 10 Feature Importance')
plt.tight_layout()
plt.show()
```

### 4.5 Model Persistence

**Save Model**:
```python
import joblib

# Save trained model
joblib.dump(best_model, 'models/best_model.pkl')

# Save scaler
joblib.dump(scaler, 'models/scaler.pkl')

# Save feature names
with open('models/feature_names.txt', 'w') as f:
    for name in feature_names:
        f.write(f"{name}\n")
```

**Load Model for Inference**:
```python
# Load in Streamlit app
@st.cache_resource
def load_model():
    model = joblib.load('models/best_model.pkl')
    scaler = joblib.load('models/scaler.pkl')
    with open('models/feature_names.txt') as f:
        features = [line.strip() for line in f]
    return model, scaler, features

model, scaler, feature_names = load_model()
```

---

## 5. API & Deployment

### 5.1 Streamlit Application

**Location**: `app.py`

**Running the App**:
```bash
streamlit run app.py
```

**Access Points**:
- Local: http://localhost:8501
- Network: http://[IP_ADDRESS]:8501

### 5.2 Application Features

**Tab 1: 🔮 Prediction**
- Input 30 medical features
- Load example benign/malignant cases
- Predict diagnosis with probability
- Display risk assessment (4 levels)
- Show confidence metrics

**Tab 2: 📊 Model Info**
- Model type and hyperparameters
- Performance metrics (Accuracy, Precision, Recall, F1, ROC-AUC)
- Model architecture description

**Tab 3: 📈 Feature Guide**
- Explanation of all 30 features
- Feature categories (mean, error, worst)
- Standardization note

**Tab 4: ℹ️ About**
- Project background
- Team information
- Contact details

### 5.3 Prediction API (Sample Implementation)

For REST API deployment:

```python
from fastapi import FastAPI
import joblib
import numpy as np

app = FastAPI()

# Load model
model = joblib.load('models/best_model.pkl')
scaler = joblib.load('models/scaler.pkl')

@app.post("/predict/")
async def predict(features: list):
    """
    Predict diagnosis from medical features
    
    Args:
        features: List of 30 feature values
    
    Returns:
        {
            "prediction": 0 or 1,
            "probability": float,
            "risk_level": "LOW|MODERATE|HIGH|VERY_LOW"
        }
    """
    # Prepare input
    X = np.array(features).reshape(1, -1)
    X_scaled = scaler.transform(X)
    
    # Predict
    pred = model.predict(X_scaled)[0]
    proba = model.predict_proba(X_scaled)[0, 1]
    
    # Determine risk
    if proba > 0.8:
        risk = "HIGH"
    elif proba > 0.5:
        risk = "MODERATE"
    elif proba > 0.2:
        risk = "LOW"
    else:
        risk = "VERY_LOW"
    
    return {
        "prediction": int(pred),
        "probability": float(proba),
        "risk_level": risk
    }
```

**Usage**:
```bash
# Install FastAPI
pip install fastapi uvicorn

# Run server
uvicorn main:app --reload

# Test endpoint
curl -X POST "http://localhost:8000/predict/" \
  -H "Content-Type: application/json" \
  -d '[14.13, 20.68, 91.49, 629.0, ...]'
```

---

## 6. Testing & Validation

### 6.1 Unit Tests

**Location**: `test_project.py`

**Test Execution**:
```bash
python test_project.py
```

**Test Coverage**:

| Test # | Purpose | Expected Result |
|--------|---------|-----------------|
| 1 | Library imports | All imports successful |
| 2 | Data loading | 569 samples, 30 features |
| 3 | Preprocessing | Train: 398, Test: 171 |
| 4 | Model training | Model fits without error |
| 5 | Evaluation metrics | Accuracy > 95% |

**Sample Test Code**:
```python
def test_data_loading():
    """Test dataset loads correctly"""
    from sklearn.datasets import load_breast_cancer
    data = load_breast_cancer()
    
    assert data.data.shape == (569, 30), "Shape mismatch"
    assert len(data.target) == 569, "Target length mismatch"
    print("[✓] Data Loading Test PASSED")

def test_model_training():
    """Test model trains successfully"""
    from sklearn.ensemble import RandomForestClassifier
    
    model = RandomForestClassifier(n_estimators=100, random_state=42)
    model.fit(X_train, y_train)
    
    assert hasattr(model, 'predict'), "Model missing predict method"
    print("[✓] Model Training Test PASSED")
```

### 6.2 Integration Testing

**Manual Testing Workflow**:

1. **Load Streamlit App**:
   ```bash
   streamlit run app.py
   ```

2. **Test Prediction Tab**:
   - Click "Load Benign Example" → Should show ✅ LOW RISK
   - Click "Load Malignant Example" → Should show 🔴 HIGH RISK
   - Manually adjust features → Should update predictions in real-time

3. **Test Model Info Tab**:
   - Verify displayed metrics match notebook outputs
   - Check that hyperparameters are correct

4. **Test Feature Guide Tab**:
   - Verify all 30 features are listed with descriptions

### 6.3 Performance Validation

**Baseline Metrics**:
```python
# Expected performance on test set
expected_metrics = {
    'accuracy': 0.97,      # >= 97%
    'precision': 0.96,     # >= 96%
    'recall': 0.99,        # >= 99%
    'f1_score': 0.97,      # >= 97%
    'roc_auc': 0.985       # >= 98.5%
}

# Validate actual vs expected
for metric, expected_value in expected_metrics.items():
    actual = computed_metrics[metric]
    assert actual >= expected_value, \
        f"{metric} failed: {actual} < {expected_value}"
```

---

## 7. Troubleshooting

### 7.1 Common Issues

**Issue 1: "Module not found" error**
```
Error: ModuleNotFoundError: No module named 'streamlit'
```

**Solution**:
```bash
pip install -r requirements.txt
# or
pip install streamlit
```

**Issue 2: Model files not found**
```
Error: FileNotFoundError: models/best_model.pkl not found
```

**Solution**:
1. Run the Jupyter notebook first to train and save models
2. Verify models/ directory exists
3. Check file permissions

**Issue 3: Port already in use**
```
Error: Address already in use
```

**Solution**:
```bash
# Streamlit uses port 8501 by default
streamlit run app.py --logger.level=debug --client.showErrorDetails=true

# Or use different port
streamlit run app.py --server.port 8502
```

**Issue 4: Predictions always show "MALIGNANT"**
```
All predictions showing high malignancy probability
```

**Solution**: 
- Check that default feature values are realistic (not all zeros)
- Verify scaler is applied correctly
- Confirm model was trained correctly

### 7.2 Debugging Tips

**Enable Verbose Output**:
```python
import logging
logging.basicConfig(level=logging.DEBUG)

# In Streamlit
st.write("Debug info:", model.get_params())
```

**Model Sanity Checks**:
```python
# Verify model makes reasonable predictions
test_samples = [benign_sample, malignant_sample]
predictions = model.predict(test_samples)
probabilities = model.predict_proba(test_samples)

print(f"Benign prediction: {predictions[0]}")  # Should be 0
print(f"Malignant prediction: {predictions[1]}")  # Should be 1
```

---

## 8. Maintenance & Monitoring

### 8.1 Model Monitoring

**Performance Metrics to Track**:
- Accuracy on new data
- Precision and Recall drift
- Distribution of prediction probabilities
- Feature importance changes

**Implementation**:
```python
def monitor_model_performance(y_true, y_pred, y_proba):
    """Monitor model performance metrics"""
    metrics = {
        'timestamp': datetime.now(),
        'accuracy': accuracy_score(y_true, y_pred),
        'precision': precision_score(y_true, y_pred),
        'recall': recall_score(y_true, y_pred),
        'f1': f1_score(y_true, y_pred),
        'roc_auc': roc_auc_score(y_true, y_proba)
    }
    
    # Log to database or file
    save_to_monitoring_log(metrics)
    
    # Alert if metrics degrade
    if metrics['accuracy'] < 0.95:
        send_alert("Model accuracy dropped below 95%")
    
    return metrics
```

### 8.2 Model Retraining

**Triggers for Retraining**:
1. Performance degradation detected
2. New data available (monthly/quarterly)
3. Class distribution changes significantly
4. Stakeholder request for model update

**Retraining Pipeline**:
```bash
# 1. Collect new data
python scripts/collect_new_data.py

# 2. Run full training pipeline
jupyter nbconvert --to notebook --execute AI_ML_Complete_Guide.ipynb

# 3. Validate new model
python test_project.py

# 4. Compare performance
python scripts/compare_models.py old_model.pkl new_model.pkl

# 5. Deploy if metrics approved
python scripts/deploy_model.py new_model.pkl
```

### 8.3 Dependency Management

**Check for Outdated Packages**:
```bash
pip list --outdated
```

**Update Packages**:
```bash
pip install --upgrade -r requirements.txt
```

**Update requirements.txt**:
```bash
pip freeze > requirements.txt
```

### 8.4 Logging & Documentation

**Application Logging**:
```python
import logging
from datetime import datetime

# Configure logging
logging.basicConfig(
    filename=f'logs/app_{datetime.now().date()}.log',
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)

logger = logging.getLogger(__name__)

# Log events
logger.info("Application started")
logger.warning("High confidence malignant prediction: 99.2%")
logger.error("Model file not found")
```

**Change Log** (version tracking):
```
## v1.1 (Planned)
- Add LIME explainability
- Implement confidence intervals
- Deploy REST API

## v1.0 (Current)
- Random Forest model: 97.08% accuracy
- Streamlit web app with 4 tabs
- Comprehensive documentation
- 5-test automated test suite
```

---

## Quick Reference Commands

```bash
# Development
streamlit run app.py                    # Run web app
python test_project.py                 # Run tests
jupyter notebook                       # Open Jupyter

# Git operations
git status                             # Check status
git add .                              # Stage changes
git commit -m "message"               # Commit
git push                              # Push to remote

# Environment management
pip install -r requirements.txt       # Install dependencies
pip freeze > requirements.txt         # Update requirements
python -m venv venv                   # Create venv

# Maintenance
python scripts/monitor_model.py       # Check performance
python scripts/retrain_model.py       # Retrain model
```

---

**Last Updated**: November 2024  
**Maintained By**: AI/ML Development Team  
**Contact**: [Your Email]

For additional support, refer to:
- README.md (User Guide)
- PROJECT_REPORT.md (Comprehensive Report)
- QUICK_REFERENCE.md (Code Snippets)
