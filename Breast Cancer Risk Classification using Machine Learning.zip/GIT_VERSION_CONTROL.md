# Version Control Guide - Git & GitHub

**Version**: 1.0  
**Date**: November 2024  

---

## Table of Contents

1. [Getting Started with Git](#1-getting-started-with-git)
2. [Common Git Workflows](#2-common-git-workflows)
3. [GitHub Setup](#3-github-setup)
4. [Branching Strategy](#4-branching-strategy)
5. [Commit Best Practices](#5-commit-best-practices)
6. [Collaboration & Pull Requests](#6-collaboration--pull-requests)
7. [Troubleshooting](#7-troubleshooting)

---

## 1. Getting Started with Git

### 1.1 Git Initialization (Already Done ✓)

The repository has been initialized with:
```bash
git init                          # Created .git directory
git config user.name "AI ML Developer"
git config user.email "dev@healthcareai.local"
```

### 1.2 Current Repository Status

```
Repository: healthcare-ai-diagnosis
Branch: master
Commits: 1 (Initial commit)
Files tracked: 18
Status: Clean (no uncommitted changes)
```

**Initial Commit Contents**:
```
✓ .gitignore                    - Git ignore rules
✓ .streamlit/config.toml        - Streamlit configuration
✓ AI_ML_Complete_Guide.ipynb    - ML training notebook
✓ PROJECT_REPORT.md             - Comprehensive report
✓ TECHNICAL_DOCUMENTATION.md    - Technical guide
✓ app.py                        - Streamlit web app
✓ test_project.py               - Unit tests
✓ models/best_model.pkl         - Trained model
✓ models/scaler.pkl             - Feature scaler
✓ models/feature_names.txt      - Feature names
✓ requirements.txt              - Python dependencies
✓ README.md                     - User guide
✓ And 6 additional documentation files
```

### 1.3 Verify Git Configuration

```bash
git config --list | grep user    # View user config
git log --oneline                # View commit history
git status                       # Check current status
```

---

## 2. Common Git Workflows

### 2.1 Day-to-Day Development

**Workflow: Making Changes and Committing**

```bash
# 1. Check status of changed files
git status

# 2. View differences
git diff                         # Unstaged changes
git diff --staged               # Staged changes

# 3. Stage specific files
git add file1.py file2.py       # Stage specific files
git add .                       # Stage all changes
git add models/                 # Stage entire directory

# 4. Commit changes
git commit -m "Clear message of what changed"

# 5. View commit history
git log --oneline -5            # Last 5 commits
git log --graph --oneline --all # Visual branch graph
```

**Example Commit Sequence**:
```bash
# Update model with better hyperparameters
git add AI_ML_Complete_Guide.ipynb
git commit -m "Improve model accuracy: RF n_estimators=200, max_depth=20"

# Fix app styling issue
git add app.py
git commit -m "Fix: Improve risk assessment display colors and layout"

# Add documentation
git add TECHNICAL_DOCUMENTATION.md
git commit -m "Add comprehensive technical documentation"

# View what we did
git log --oneline -3
```

### 2.2 Undoing Changes

**Before Staging**:
```bash
# Discard changes in working directory
git checkout -- filename.py

# Or use newer syntax
git restore filename.py

# Discard ALL changes
git reset --hard HEAD
```

**After Staging**:
```bash
# Unstage file
git reset HEAD filename.py
git restore --staged filename.py

# Then discard changes
git checkout -- filename.py
```

**After Committing**:
```bash
# View commits
git log --oneline -n 5

# Undo last commit (keep changes)
git reset --soft HEAD~1

# Undo last commit (discard changes)
git reset --hard HEAD~1

# Revert a specific commit (creates new commit)
git revert <commit-hash>
```

### 2.3 Viewing History

```bash
# Simple log
git log --oneline

# Detailed log with statistics
git log --stat

# Graph showing branches
git log --graph --all --oneline --decorate

# Changes in specific file
git log --oneline filename.py
git log -p filename.py          # Show actual changes

# Blame (who changed each line)
git blame filename.py

# Show specific commit
git show <commit-hash>
```

---

## 3. GitHub Setup

### 3.1 Create GitHub Repository

**Steps**:
1. Go to [github.com](https://github.com)
2. Click "+" → "New repository"
3. Name: `healthcare-ai-diagnosis`
4. Description: "AI/ML Healthcare Diagnosis Prediction System - Breast Cancer Classification"
5. Choose: **Public** (for portfolio) or **Private** (for confidential)
6. Do NOT initialize with README (we have one)
7. Click "Create repository"

### 3.2 Connect Local to Remote

```bash
# Add remote repository
git remote add origin https://github.com/YOUR_USERNAME/healthcare-ai-diagnosis.git

# Verify remote is added
git remote -v
# Output should show:
# origin  https://github.com/YOUR_USERNAME/healthcare-ai-diagnosis.git (fetch)
# origin  https://github.com/YOUR_USERNAME/healthcare-ai-diagnosis.git (push)

# Push to GitHub
git branch -M main              # Rename master to main (GitHub standard)
git push -u origin main         # Push and set upstream
```

### 3.3 Authenticate with GitHub

**Option 1: Personal Access Token (Recommended)**
```bash
# Create token at: https://github.com/settings/tokens
# Scopes needed: repo, read:user

# When prompted for password, paste the token
git push
```

**Option 2: SSH Key**
```bash
# Generate SSH key
ssh-keygen -t ed25519 -C "your_email@example.com"

# Add to ssh-agent
eval "$(ssh-agent -s)"
ssh-add ~/.ssh/id_ed25519

# Add public key to GitHub: https://github.com/settings/keys

# Clone using SSH
git clone git@github.com:YOUR_USERNAME/healthcare-ai-diagnosis.git
```

---

## 4. Branching Strategy

### 4.1 Branch Types

**Main Branches**:
- `main` or `master`: Production-ready code
- `develop`: Integration branch for features

**Feature Branches**:
- `feature/*`: New features
- `bugfix/*`: Bug fixes
- `docs/*`: Documentation updates
- `refactor/*`: Code refactoring
- `experiment/*`: Experimental work

### 4.2 Feature Branch Workflow

```bash
# 1. Create feature branch from develop
git checkout develop
git pull origin develop
git checkout -b feature/improve-model-accuracy

# 2. Make changes and commit
git add .
git commit -m "Add GridSearchCV hyperparameter tuning for better accuracy"

# 3. Push to GitHub
git push origin feature/improve-model-accuracy

# 4. Create Pull Request on GitHub
# (Instructions below in section 6)

# 5. After PR is merged, delete feature branch
git checkout develop
git pull origin develop
git branch -d feature/improve-model-accuracy
git push origin --delete feature/improve-model-accuracy
```

### 4.3 Common Branch Commands

```bash
# List branches
git branch                      # Local branches
git branch -a                  # Local + remote branches
git branch -r                  # Remote branches only

# Create branch
git branch feature/my-feature
git checkout -b feature/my-feature   # Create and switch

# Switch branches
git checkout main
git switch main                # Newer syntax

# Rename branch
git branch -m old-name new-name

# Delete branch
git branch -d branch-name      # Safe delete (merged only)
git branch -D branch-name      # Force delete

# Push branch to GitHub
git push origin feature/my-feature

# Track remote branch
git checkout --track origin/feature/my-feature
```

---

## 5. Commit Best Practices

### 5.1 Commit Message Format

**Structure**: `<type>: <subject>`

**Types**:
- `feat`: New feature
- `fix`: Bug fix
- `docs`: Documentation
- `refactor`: Code refactoring
- `test`: Test additions
- `perf`: Performance improvement
- `chore`: Maintenance

**Examples**:
```
✓ Good:
feat: Add LIME explainability to model predictions
fix: Correct risk assessment threshold from 0.8 to 0.75
docs: Add deployment guide to TECHNICAL_DOCUMENTATION.md
refactor: Improve data preprocessing pipeline efficiency
test: Add test for malignant case prediction

✗ Bad:
updated stuff
fixed bug
changes
asdf
WIP
```

### 5.2 Commit Message Best Practices

1. **Subject line**: 50 characters or less
2. **Blank line**: Separate subject from body
3. **Body**: Explain WHAT and WHY, not HOW
4. **Imperative mood**: "Add" not "Added" or "Adds"
5. **Reference issues**: "Fixes #123" or "Closes #456"

**Template**:
```
<type>: <subject (imperative, 50 chars or less)>

<body (optional, explain what and why)>

<footer (optional, reference issues)>

Example:
---
feat: Improve Random Forest model accuracy to 97%

Tuned hyperparameters using GridSearchCV:
- Increased n_estimators from 100 to 200
- Set max_depth to 20 for better regularization
- Adjusted min_samples_split to 5

Model now achieves 97.08% accuracy on test set, up from 96.5%.
Precision maintained at 96.4%, recall improved to 99.07%.

Fixes #45
```

### 5.3 Commit Frequency

**Guidelines**:
- **Small, atomic commits**: One logical change per commit
- **Frequent commits**: Multiple times per day
- **Not too small**: Include related changes together
- **Not too large**: Avoid mixing unrelated changes

**Example Good Practice**:
```
✓ Commit 1: Add feature X basic functionality
✓ Commit 2: Add unit tests for feature X
✓ Commit 3: Update documentation for feature X
✓ Commit 4: Fix bug in feature X

✗ Avoid: Single giant commit with everything
✗ Avoid: Committing incomplete work
```

---

## 6. Collaboration & Pull Requests

### 6.1 Pull Request Workflow

**On Your Local Machine**:
```bash
# 1. Create feature branch
git checkout -b feature/new-model

# 2. Make changes and commit
git add .
git commit -m "feat: Add new ensemble model"

# 3. Push to GitHub
git push origin feature/new-model
```

**On GitHub**:
```
1. Go to repository homepage
2. Click "Compare & pull request"
3. Fill in PR template:
   - Title: Brief description
   - Description: What, why, how
   - Screenshots: If visual changes
4. Link related issues: "Fixes #123"
5. Click "Create pull request"
```

**PR Description Template**:
```markdown
## Description
Brief description of the changes

## Type of Change
- [ ] New feature
- [ ] Bug fix
- [ ] Documentation update
- [ ] Performance improvement

## Related Issues
Fixes #123

## Changes Made
- Change 1
- Change 2
- Change 3

## Testing
- [ ] Unit tests pass
- [ ] Integration tests pass
- [ ] Manual testing completed

## Checklist
- [ ] Code follows style guidelines
- [ ] Documentation updated
- [ ] No breaking changes
- [ ] Tested on Windows/Mac/Linux
```

### 6.2 Code Review Process

**Reviewer Checklist**:
- [ ] Code is clear and well-documented
- [ ] Tests cover new functionality
- [ ] No breaking changes
- [ ] Performance impact assessed
- [ ] Security considerations addressed
- [ ] Documentation is updated

**Requesting Changes**:
```bash
# Reviewer: Click "Request changes" on PR

# Developer: Address feedback
git add .
git commit -m "Address review feedback: Improve error handling"
git push origin feature/new-model

# GitHub automatically updates the PR
# Reviewer: Re-review and approve/merge
```

### 6.3 Merging Pull Requests

**On GitHub**:
1. All checks pass (tests, reviews)
2. Click "Squash and merge" (recommended for features)
3. Or "Create a merge commit" (for main releases)
4. Delete branch after merge (GitHub offers this)

**Locally**:
```bash
# Pull updated main
git checkout main
git pull origin main

# Delete local feature branch
git branch -d feature/new-model
```

---

## 7. Troubleshooting

### 7.1 Common Issues

**Issue: "fatal: not a git repository"**
```bash
# You're not in a git repository directory
cd /path/to/healthcare-ai-diagnosis
git status
```

**Issue: "Your branch is ahead of 'origin/main' by 2 commits"**
```bash
# Push your local commits
git push origin main
```

**Issue: "Merge conflict"**
```bash
# When pulling or merging, conflicts occur
git status  # See which files have conflicts

# Edit conflicted files (look for <<<, ===, >>>)
# Then:
git add .
git commit -m "Resolve merge conflicts"
git push
```

**Issue: "detached HEAD state"**
```bash
# You're on a specific commit, not a branch
git checkout main       # Return to main branch
git checkout -b branch-name  # Or create new branch from here
```

**Issue: "accidentally committed to wrong branch"**
```bash
# Get commit hash
git log --oneline -3

# Reset branch
git reset --soft HEAD~1  # Undo last commit, keep changes

# Switch to correct branch
git checkout correct-branch
git commit -m "message"
```

### 7.2 Useful Git Commands

```bash
# Search commit history
git log --grep="keyword"        # Search commit messages
git log -S "code_snippet"       # Search in code changes
git log --author="name"         # Search by author

# Find who broke something
git bisect start
git bisect bad HEAD
git bisect good <commit-hash>

# Temporarily stash changes
git stash                       # Save work
git stash list                  # View stashes
git stash pop                   # Restore work
git stash drop stash@{0}        # Delete stash

# Clean up repository
git gc                          # Garbage collection
git clean -fd                   # Remove untracked files
```

---

## Project-Specific Guidelines

### Branches for This Project

```
main (or master)
├── Latest stable release
└── Protected branch (requires PR review)

develop
├── Integration branch
├── Feature base
└── Testing before main release

Feature branches:
├── feature/model-improvements
├── feature/api-development
├── feature/mobile-app
├── bugfix/risk-assessment-fix
└── docs/deployment-guide
```

### Commit Examples for This Project

```bash
# Model improvements
git commit -m "feat: Improve Random Forest accuracy to 97.08%"

# Web app updates
git commit -m "fix: Correct risk assessment display colors"

# Documentation
git commit -m "docs: Add deployment and troubleshooting guides"

# Testing
git commit -m "test: Add unit tests for model evaluation"

# Bug fixes
git commit -m "fix: Handle edge case in feature standardization"
```

### Recommended Deployment Flow

```
Feature Branch (feature/*)
    ↓
    Code Review (Pull Request)
    ↓
Tests Pass ✓
    ↓
    Merge to develop
    ↓
    Integration Testing
    ↓
    Merge to main (Release)
    ↓
    Tag Release (v1.0.0)
    ↓
    Deploy to Production
```

---

## Current Repository Status

```
Repository: healthcare-ai-diagnosis
Remote: Not yet configured (optional)
Branch: master
Commits: 1
  - Initial commit with complete project

Status: ✓ Clean working tree
Files tracked: 18
.gitignore: ✓ Configured

To push to GitHub:
1. Create repository on GitHub
2. Run: git remote add origin <GitHub-URL>
3. Run: git push -u origin master
```

---

## Next Steps

1. **Create GitHub Repository**
   - Go to github.com and create new repository
   - Copy the repository URL

2. **Add Remote**
   ```bash
   git remote add origin <your-github-url>
   git push -u origin master
   ```

3. **Set Up Branches**
   ```bash
   git checkout -b develop
   git push -u origin develop
   ```

4. **Share with Team**
   - Add collaborators on GitHub
   - Set up branch protection rules
   - Configure merge requirements (PR review, tests)

5. **Continuous Integration (Optional)**
   - GitHub Actions for automated tests
   - Auto-deploy on merge to main

---

**For Questions**: Refer to official Git documentation at [git-scm.com](https://git-scm.com)

**Last Updated**: November 2024
